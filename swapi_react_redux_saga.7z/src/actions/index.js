import { SET_STAR_WAR_PEOPLE, GET_STAR_WAR_PEOPLE_SAGA } from '../constants';

export function getStarwarsSaga() {
  return {
    type: GET_STAR_WAR_PEOPLE_SAGA
  };
}

export function setStarWarPeople(response) {
  return {
    type: SET_STAR_WAR_PEOPLE,
    response
  };
}
