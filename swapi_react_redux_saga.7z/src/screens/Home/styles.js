const styles = {
  container: {
  },
};

export default styles;
