/* eslint-disable react/button-has-type */
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { getStarwarsSaga } from '../../actions';
import { API_BASE_URL } from '../../constants';
import {DebounceInput} from 'react-debounce-input';
import './index.css';

class Home extends Component {
  handlepagingButtonClick = (apiURL) => {
    const { getStarwarsSagaAction } = this.props;
    getStarwarsSagaAction(apiURL);
  };

  generateProfilePic = () => (
    <svg viewBox="18 18 43 43">
      <path d="M58.2717,52.6987 C58.1827,52.7337 58.0907,52.7497 57.9997,52.7497 C57.6997,52.7497 57.4167,52.5687 57.3017,52.2727 L51.8467,38.2607 C50.4047,34.6567 48.6217,33.2497 45.4887,33.2497 C43.4097,33.2497 41.6667,34.5387 41.6497,34.5527 C40.7247,35.2467 39.2757,35.2437 38.3497,34.5527 C38.3347,34.5387 36.5737,33.2497 34.5107,33.2497 C31.3787,33.2497 29.5957,34.6567 28.1507,38.2667 L22.6987,52.2727 C22.5487,52.6577 22.1117,52.8497 21.7277,52.6987 C21.3427,52.5497 21.1507,52.1147 21.3017,51.7277 L26.7557,37.7167 C28.4287,33.5327 30.7477,31.7497 34.5107,31.7497 C37.0847,31.7497 39.1627,33.2867 39.2497,33.3507 C39.6427,33.6467 40.3577,33.6467 40.7497,33.3507 C40.8367,33.2867 42.9157,31.7497 45.4887,31.7497 C49.2517,31.7497 51.5707,33.5327 53.2417,37.7107 L58.6987,51.7277 C58.8487,52.1147 58.6577,52.5497 58.2717,52.6987 L58.2717,52.6987 Z M48.9997,41.4997 L42.9997,41.4997 C42.1747,41.4997 41.4997,41.1627 41.4997,40.7497 L41.4997,38.4997 C41.4997,37.6747 42.0637,36.6287 42.7527,36.1757 C42.7527,36.1757 43.7797,35.4997 45.2497,35.4997 C48.1497,35.4997 49.5747,37.3197 49.5747,37.3197 C50.0837,37.9687 50.4997,39.1747 50.4997,39.9997 C50.4997,40.8247 49.8247,41.4997 48.9997,41.4997 L48.9997,41.4997 Z M48.9997,56.1247 C48.3777,56.1247 47.8747,55.6217 47.8747,54.9997 C47.8747,54.3777 48.3777,53.8747 48.9997,53.8747 C49.6217,53.8747 50.1247,54.3777 50.1247,54.9997 C50.1247,55.6217 49.6217,56.1247 48.9997,56.1247 L48.9997,56.1247 Z M45.9997,54.9997 L44.4997,54.9997 L44.4997,50.4997 L45.9997,51.9997 L45.9997,54.9997 Z M40.7497,54.9997 L42.9997,54.9997 L42.9997,48.9997 L40.7497,48.9997 L40.7497,54.9997 Z M37.7497,47.4997 L37.7497,45.2497 C37.7497,44.0067 38.7577,42.9997 39.9997,42.9997 C41.2427,42.9997 42.2497,44.0067 42.2497,45.2497 L42.2497,47.4997 L37.7497,47.4997 Z M36.9997,54.9997 L39.2497,54.9997 L39.2497,48.9997 L36.9997,48.9997 L36.9997,54.9997 Z M35.4997,54.9997 L33.9997,54.9997 L33.9997,51.9997 L35.4997,50.4997 L35.4997,54.9997 Z M29.4997,39.9997 C29.4997,39.1747 29.9167,37.9687 30.4247,37.3197 C30.4247,37.3197 31.8507,35.4997 34.7497,35.4997 C36.2207,35.4997 37.2467,36.1757 37.2467,36.1757 C37.9357,36.6287 38.4997,37.6747 38.4997,38.4997 L38.4997,40.7497 C38.4997,41.1627 37.8247,41.4997 36.9997,41.4997 L30.9997,41.4997 C30.1747,41.4997 29.4997,40.8247 29.4997,39.9997 L29.4997,39.9997 Z M30.9997,56.1247 C30.3777,56.1247 29.8747,55.6217 29.8747,54.9997 C29.8747,54.3777 30.3777,53.8747 30.9997,53.8747 C31.6217,53.8747 32.1247,54.3777 32.1247,54.9997 C32.1247,55.6217 31.6217,56.1247 30.9997,56.1247 L30.9997,56.1247 Z M54.9997,36.3997 L54.9997,30.9997 C54.9997,24.3997 49.5997,18.9997 42.9997,18.9997 L36.9997,18.9997 C30.3997,18.9997 24.9997,24.3997 24.9997,30.9997 L24.9997,36.3997 L18.9997,51.9997 C18.9997,54.9997 28.4017,60.9997 39.9997,60.9997 C51.5977,60.9997 60.9997,54.9997 60.9997,51.9997 L54.9997,36.3997 Z" fillRule="evenodd" />
    </svg>
  );

  generateCard = item => (
    <div className="card card-body" key={item.name}>
      <div className="card-header">{this.generateProfilePic()}</div>
      <div className="card-title">{item.name}</div>
    </div>
  );

  generatePager = (next, previous) => (
    <div>
      {next && <button onClick={() => this.handlepagingButtonClick(next)}>next</button>}
      {next && previous && '::'}
      {previous && <button onClick={() => this.handlepagingButtonClick(previous)}>previous</button>}
    </div>
  );

  nameChanged = (e) => {
    const userInputValue = e.target.value;
    const apiURL = `${API_BASE_URL}${userInputValue}`;
    const { getStarwarsSagaAction } = this.props;
    getStarwarsSagaAction(apiURL);
  }

  handleBtnOnClick = () => {
    const apiURL = `${API_BASE_URL}${'o'}`;
    const { getStarwarsSagaAction } = this.props;
    getStarwarsSagaAction(apiURL);
  }

  render() {
    const { response, loading } = this.props;
    return (
      <div>
        <div>
          <h3>To search for your favourite StarWars Character type below and wait</h3>
          <DebounceInput debounceTimeout={400} onChange={this.nameChanged} placeholder="type here to search by name" autofocus />
        </div>
        <br />
        {!loading && response && response.results && response.results.length === 0
          && <h3>No results found !!</h3>
        }
        {!loading && response && response.results && response.results.length > 0
          && this.generatePager(response.next, response.previous)
        }
        {!loading && (
        <div className="grid-container">
            {response && response.results && response.results.length > 0
            && response.results.map(item => this.generateCard(item))}
        </div>
        )
        }
        {loading && <div>Loading....</div>}
        <br />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  response: state.starWarsReducer.response,
  loading: state.starWarsReducer.loading
});

const mapDispatchToProps = dispatch => ({
  getStarwarsSagaAction: apiURL => dispatch(getStarwarsSaga(apiURL))
});

export default connect(mapStateToProps, mapDispatchToProps)(Home);
