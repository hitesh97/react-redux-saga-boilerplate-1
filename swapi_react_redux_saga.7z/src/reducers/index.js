import { combineReducers } from 'redux';
import { SET_STAR_WAR_PEOPLE } from '../constants';

const initialState = { response: {} };

function starWarsReducer(state = initialState, action) {
  switch (action.type) {
    case SET_STAR_WAR_PEOPLE: {
      return {
        ...state,
        response: action.response
      };
    }
    default:
      return state;
  }
}

export default combineReducers({
  starWarsReducer
});
