import { put, takeLatest, call, all } from 'redux-saga/effects';

import { GET_STAR_WAR_PEOPLE_SAGA } from '../../constants';
import { setStarWarPeople } from '../../actions';
import { getStarWarsPerson } from '../../lib/api';

function* workerStarwarsSaga() {
  const response = yield call(getStarWarsPerson);
  yield put(setStarWarPeople(response));
}

export default function* watchGetStarWarsSaga() {
  yield all([yield takeLatest(GET_STAR_WAR_PEOPLE_SAGA, workerStarwarsSaga)]);
}
